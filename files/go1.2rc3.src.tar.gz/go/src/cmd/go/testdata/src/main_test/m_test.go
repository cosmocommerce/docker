package main_test

import (
	. "main_test"
	"testing"
)

func Test1(t *testing.T) {
	F()
}
